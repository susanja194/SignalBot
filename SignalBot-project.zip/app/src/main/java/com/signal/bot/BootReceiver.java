package com.signal.bot;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Restarts the bot after phone reboot / app update, if it was ON. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Prefs.enabled(context)) {
            try {
                context.startForegroundService(new Intent(context, ScannerService.class));
            } catch (Exception ignored) {
            }
        }
    }
}
