package com.signal.bot;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

/** Settings + saved signal history. */
public final class Prefs {
    private Prefs() {}

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("signalbot", Context.MODE_PRIVATE);
    }

    public static boolean enabled(Context c) { return sp(c).getBoolean("enabled", false); }
    public static void setEnabled(Context c, boolean v) { sp(c).edit().putBoolean("enabled", v).apply(); }

    public static int intervalMin(Context c) { return sp(c).getInt("interval", 5); }
    public static String timeframe(Context c) { return sp(c).getString("tf", "15m"); }
    public static int topCoins(Context c) { return sp(c).getInt("top", 100); }
    public static int minVolMillion(Context c) { return sp(c).getInt("minvol", 5); }
    public static int buyThreshold(Context c) { return sp(c).getInt("buyth", 5); }
    public static int sellThreshold(Context c) { return sp(c).getInt("sellth", 4); }
    public static float volMult(Context c) { return sp(c).getFloat("volmult", 2.0f); }
    public static boolean btcFilter(Context c) { return sp(c).getBoolean("btcfilter", true); }
    public static int cooldownMin(Context c) { return sp(c).getInt("cooldown", 120); }

    public static void saveSettings(Context c, int interval, String tf, int top, int minVol,
                                    int buyTh, int sellTh, float volMult, boolean btc, int cooldown) {
        sp(c).edit()
                .putInt("interval", Math.max(1, interval))
                .putString("tf", tf)
                .putInt("top", Math.max(5, Math.min(400, top)))
                .putInt("minvol", Math.max(0, minVol))
                .putInt("buyth", Math.max(1, buyTh))
                .putInt("sellth", Math.max(1, sellTh))
                .putFloat("volmult", Math.max(1.1f, volMult))
                .putBoolean("btcfilter", btc)
                .putInt("cooldown", Math.max(0, cooldown))
                .apply();
    }

    public static String status(Context c) { return sp(c).getString("status", "Abhi start nahi hua"); }
    public static void setStatus(Context c, String s) { sp(c).edit().putString("status", s).apply(); }

    /** True if this coin+side may alert again (cooldown passed); also records the time. */
    public static boolean checkAndMarkCooldown(Context c, String symbol, String side) {
        String key = "cd_" + symbol + "_" + side;
        long now = System.currentTimeMillis();
        long last = sp(c).getLong(key, 0);
        if (now - last < cooldownMin(c) * 60_000L) return false;
        sp(c).edit().putLong(key, now).apply();
        return true;
    }

    public static synchronized void addSignal(Context c, String side, String symbol, double price,
                                              int score, String reasons) {
        try {
            JSONArray old = new JSONArray(sp(c).getString("signals", "[]"));
            JSONArray arr = new JSONArray();
            JSONObject o = new JSONObject();
            o.put("t", System.currentTimeMillis());
            o.put("side", side);
            o.put("sym", symbol);
            o.put("price", price);
            o.put("score", score);
            o.put("why", reasons);
            arr.put(o);
            for (int i = 0; i < old.length() && i < 199; i++) arr.put(old.get(i));
            sp(c).edit().putString("signals", arr.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    public static JSONArray signals(Context c) {
        try {
            return new JSONArray(sp(c).getString("signals", "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    public static void clearSignals(Context c) { sp(c).edit().putString("signals", "[]").apply(); }
}
